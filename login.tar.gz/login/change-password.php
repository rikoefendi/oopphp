<?php

  require_once"core/Init.php";
  if(!Session::exits('username')){
    header('location: login.php');
  }
  $errors = array();

  if(Submit::get('register')){
    if(Token::check(Submit::get('token'))){
      $validation = $validation->check(array(
        "password_baru"    => array(
                            'required' => true,
                            'min'      => 3
                          ),
        "password"    => array(
                            'required' => true,
                            'min'      => 3
                          ),
        "password_verify"    => array(
                            'required' => true,
                            'match'    => 'password'
                          )
      ));
      if($validation->passed()){
        $user->register_user(array(
          "password"    => password_hash(Submit::get('password'), PASSWORD_DEFAULT)
        ));
          Session::set('username', Submit::get('username'));
          header('location: profile.php');
      }else{
        $errors = $validation->error();
      }//emd validation
    }//end token
  }//end submit
  require_once"templates/Header.php";

?>

<form action="change-password.php" method="post">

  <label>password lama</label>
  <input type="password" name="password_lama" value=""><br>
  <label>Password</label>
  <input type="password" name="password" value=""><br>
  <label>Password Verify</label>
  <input type="password" name="password_verify" value=""><br>
  <input type="hidden" name="token" value="<?php echo Token::generate(); ?>"><br>
  <input type="submit" name="change" value="Change Password">

  <?php if(!empty($errors)){ ?>
    <div id="errors">
      <?php foreach ($errors as $error){ ?>
        <li> <?php echo $error; ?> </li>
      <?php } ?>
    </div>
  <?php } ?>

</form>

<?php require_once"templates/Footer.php"; ?>
