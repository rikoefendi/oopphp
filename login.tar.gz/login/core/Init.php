<?php

  spl_autoload_register(function($nama){
    require_once"clasess/".$nama.".php";
  });

  $user       = new User();
  $validation = new Validation();

?>
