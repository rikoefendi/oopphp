  <footer>@Copyright by:Riko</footer>
</body>
</html>
