<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Auth oop</title>
    <link rel="stylesheet" href="assets/style.css">
  </head>
  <body>
    <header>
      <h1>Belajar Auth</h1>
      <nav>
        <a href="profile.php">Profile</a>
        <a href="register.php">Register</a>
        <a href="login.php">Login</a>
        <a href="logout.php">Logout</a>
      </nav>
    </header>
