<?php

  require 'core/Init.php';
  if(!Session::exits('username')){
    Session::flash('profile', 'anda harus login');
    header('location: login.php');
  }
  require 'templates/Header.php';
?>
  <h1>Hai <?php echo Session::get('username'); ?></h1>
<?php
  require 'templates/Footer.php';
?>
