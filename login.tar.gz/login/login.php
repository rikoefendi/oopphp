<?php

  require_once"core/Init.php";
  if(Session::exits('username')){
    header('location: profile.php');
  }
  if(Session::exits('profile')){
    echo Session::flash('profile');
  }
  $errors = array();

  if(Submit::get('login')){
    if(Token::check(Submit::get('token'))){
      $validation = $validation->check(array(
        "username"    => array( 'required' => true ),
        "password"    => array( 'required' => true )
      ));

        if($validation->passed()){
          if( $user->cek_nama(Submit::get('username')) ){
            if($user->login_user( Submit::get('username'), Submit::get('password'))){
              Session::set('username', Submit::get('username'));
              header('location: profile.php');
            }else{
              $errors[] = "login gagal";
            }
          }else{
            $errors[] = "nama belum terdaftar";
          }
        }else{
          $errors = $validation->error();
        }//emd validation
    }  
  }//end submit
  require_once"templates/Header.php";

?>

<form action="login.php" method="post">

  <label>Username</label>
  <input type="text" name="username" value=""><br>
  <label>Password</label>
  <input type="password" name="password" value=""><br>
  <input type="hidden" name="token" value="<?php echo Token::generate(); ?>"><br>
  <input type="submit" name="login" value="Login User">

  <?php if(!empty($errors)){ ?>
    <div id="errors">
      <?php foreach ($errors as $error){ ?>
        <li> <?php echo $error; ?> </li>
      <?php } ?>
    </div>
  <?php } ?>

</form>

<?php require_once"templates/Footer.php"; ?>
