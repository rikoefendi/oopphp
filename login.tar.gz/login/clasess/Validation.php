<?php

  class Validation{

    private $_passed = false,
            $_errors = array();

    public function check($items = array())
    {

      foreach ($items as $item => $rule) {
        foreach ($rule as $name => $rule_value) {
          switch ($name) {
            case 'required':
              if(trim(Submit::get($item)) == false && $rule_value == true){
                $this->addError("$item wajib diisi!");
              }
              break;
            case 'min':
              if(strlen(Submit::get($item)) < $rule_value ){
                $this->addError("$item minimal $rule_value karakter");
              }
              break;
            case 'max':
              if(strlen(Submit::get($item)) > $rule_value ){
                $this->addError("$item maximal $rule_value karakter");
              }
              break;
            case 'match':
              if( Submit::get($item) != Submit::get($rule_value) ){
                $this->addError("$rule_value harus sama!");
              }
              break;

            default:
              break;
          }//end second foreach
        }//end first foreach
      }
      if(empty($this->_errors)){
        $this->_passed = true;
      }
      return $this;
    }

    public function addError($error)
    {
      $this->_errors[] = $error;
    }
    public function error()
    {
      return $this->_errors;
    }
    public function passed()
    {
      return $this->_passed;
    }

  }

?>
