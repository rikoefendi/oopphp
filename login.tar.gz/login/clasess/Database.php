<?php

  class Database{

    private static $_INSTANCE = NULL;
    private $mysqli,
            $HOST     = "localhost",
            $USER     = "root",
            $PASS     = "",
            $DBNAME   = "crud";

    public function __construct()
    {
      $this->mysqli = new mysqli  ($this->HOST, $this->USER, $this->PASS, $this->DBNAME);
    }

    public function getinstance()
    {
      if(!isset(self::$_INSTANCE)){
        self::$_INSTANCE = new Database();
      }
      return self::$_INSTANCE;
    }

    public function insert($table, $fields)
    {

      //mengambil nama kolom
      $column = implode(', ', array_keys($fields));

      //mengambil nilai value
      $array = array();
      $i=0;
      foreach ($fields as $key => $value) {
        $array[$i] = "'".$value."'";
        $i++;
      }
      $value = implode(', ', $array);

      //query
      $query = "INSERT INTO $table ($column) VALUES ($value)";


      if($this->mysqli->query($query)) return true; else return false;
    }

    public function view($table, $column = '', $value = '')
    {
      $query = "SELECT * FROM $table WHERE $column = '$value'";
      $result = $this->mysqli->query($query);
      while( $row = $result->fetch_assoc() ){
        return $row;
      }
    }
  }


?>
