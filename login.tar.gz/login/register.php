<?php

  require_once"core/Init.php";
  if(Session::exits('username')){
    header('location: profile.php');
  }
  $errors = array();

  if(Submit::get('register')){
    if(Token::check(Submit::get('token'))){
      $validation = $validation->check(array(
        "username"    => array(
                            'required' => true,
                            'min'      => 3,
                            'max'      => 50
                          ),
        "password"    => array(
                            'required' => true,
                            'min'      => 3
                          ),
        "password_verify"    => array(
                            'required' => true,
                            'match'    => 'password'
                          )
      ));
      if( $user->cek_nama(Submit::get('username')) ){
        $errors[] = 'nama sudah terdaftar';
      }else{
        if($validation->passed()){
          $user->register_user(array(
            "username"    => Submit::get('username'),
            "password"    => password_hash(Submit::get('password'), PASSWORD_DEFAULT)
          ));
            Session::set('username', Submit::get('username'));
            header('location: register.php');
        }else{
          $errors = $validation->error();
        }//emd validation
      }//end cek_nama
    }//end token
  }//end submit
  require_once"templates/Header.php";

?>

<form action="register.php" method="post">

  <label>Username</label>
  <input type="text" name="username" value=""><br>
  <label>Password</label>
  <input type="password" name="password" value=""><br>
  <label>Password Verify</label>
  <input type="password" name="password_verify" value=""><br>
  <input type="hidden" name="token" value="<?php echo Token::generate(); ?>"><br>
  <input type="submit" name="register" value="Register User">

  <?php if(!empty($errors)){ ?>
    <div id="errors">
      <?php foreach ($errors as $error){ ?>
        <li> <?php echo $error; ?> </li>
      <?php } ?>
    </div>
  <?php } ?>

</form>

<?php require_once"templates/Footer.php"; ?>
